#include <stdio.h>
#include <stdlib.h>


int main(){

    int n;
    printf("Introduzca un número para determinar el tamaño del array: ");
    scanf("%d", &n);

    int *arr = (int*) malloc(n * sizeof(int));
    if (arr == NULL){
        printf("Error al asignar memoria.\n");
        return 1;
    }

    printf("Ingrese los números del array:\n");
    for (int i = 0; i < n; i++){
        printf("\tNúmero %d: ", i + 1);
        scanf("%d", &arr[i]);
    }

//Método de ordenación Bubblesort
int temp;
    for (int i = 0; i < n - 1; i++){
        for (int j = 0; j < n - i - 1; j++){
            if (arr[j] > arr[j+1]){
                temp = arr[j];
                arr[j] = arr[j+1];
                arr[j+1] = temp;
            }
        }
    }
 /*El primer bucle (for (i)) controla el número de pasadas sobre el array.
   El segundo bucle (for (j)) se encarga de recorrer el array y realizar los intercambios. */


    printf("Array ordenado:\n");
    for (int i = 0; i < n; i++){
        printf("%d ", arr[i]);
    }

free(arr);
return 0; 
}